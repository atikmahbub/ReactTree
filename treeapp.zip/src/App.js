import React from 'react';
import Home from './containers/Home'

function App() {
  return (
    <div>
      <Home/>
    </div>
  );
}

export default App;
